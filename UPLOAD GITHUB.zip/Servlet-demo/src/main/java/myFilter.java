

import java.io.*;


import javax.servlet.*;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebFilter(filterName = "myFilter", urlPatterns = { "/AdminServlet" })
public class myFilter implements Filter{
	
	public void init(FilterConfig arg0) throws ServletException {}
	public void doFilter(ServletRequest req,ServletResponse res,FilterChain chain) throws IOException,ServletException { 
		PrintWriter out =res.getWriter(); 
		res.setContentType("text/html");
		String password = req.getParameter("password");
		if(password.equals("admin"))
			
		{
			chain.doFilter(req, res);
		}else 
		{
			
			out.println("username or password is incorrect!");
			RequestDispatcher rd=req.getRequestDispatcher("authentication.html");
			rd.include(req, res);
		}
		
		
		} 
	
	
	
	public void destroy()
	
	{ }

}
