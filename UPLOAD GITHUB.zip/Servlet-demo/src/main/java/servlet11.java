

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/servlet11")
public class servlet11 extends HttpServlet {
	
	public void doGet (HttpServletRequest req, HttpServletResponse res) throws IOException
	
	{
		
		try {
			res.setContentType("text/html");
			PrintWriter out = res.getWriter();
			
			String n = req.getParameter("userName");
			out.println("Welcome :" + n);
			
			out.println("<a href = 'servlet2?uname="+n+"'>visit</a>");
			
			out.close();
			
			
			
			
			
		}catch (Exception e)
		{
			
			System.out.println(e);
		}
		
	}

}
