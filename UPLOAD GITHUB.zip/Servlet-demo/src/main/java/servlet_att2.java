

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.*;


@WebServlet("/page2")
public class servlet_att2 extends HttpServlet {
	
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException
	{
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		ServletContext context = getServletContext();
		String name1 =(String) context.getAttribute("company");
		
		
		out.println("Welcome to " + name1);
		out.close();
		
		
		
	}
	
	
	
}
