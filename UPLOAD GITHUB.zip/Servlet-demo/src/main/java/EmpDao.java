
import java.util.*;

import sqlconnection.emp;

import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class EmpDao {
	
	
	public static Connection getConnection(){
		Connection con = null;
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/employee", "root","root");
		}catch (Exception e)
		
		{
			
			System.out.println(e);
		}
		return con;
		
		
	}
	
	public static int save(Emp_java e1)
	
	{
		
		int status=0;
		try {
			
			Connection con =EmpDao.getConnection();
			PreparedStatement ps = con.prepareStatement("insert into emp1 values(emp_id,name,salary)");
			
			ps.setInt(1, e1.getId());
			ps.setInt(2, e1.getSalary());
			ps.setString(3, e1.getName());
			
			status=ps.executeUpdate();
			con.close();
		}catch (Exception e11)
		
		{
			System.out.println(e11);
		}
		return status;
	}
	
	public static int update (Emp_java e)
	{
		int status=0;
try {
	
			Connection con =EmpDao.getConnection();
			PreparedStatement ps = con.prepareStatement("update emp1 set name=?salary=?where emp_id=?");
			
			ps.setInt(1, e.getId());
			ps.setInt(2, e.getSalary());
			ps.setString(3, e.getName());
			
			 status = ps.executeUpdate();
			con.close();
		}catch (Exception e1)
		
		{
			System.out.println(e1);
		}
return 0;
		
	}
	
	
	public static int delete(int id)
	{
	    int status=0;
	    try
	    {
	        Connection con=EmpDao.getConnection();
	        PreparedStatement ps=con.prepareStatement("delete from emp1 where emp_id=?");
	        ps.setInt(1, id);
	                    
	        status=ps.executeUpdate();
	        con.close();
	    }catch(Exception e1)
	    {
	        System.out.println(e1);
	    }
	    return status;
	}

	
	  public static Emp_java getEmployeeById(int id)
	    {
	        Emp_java e = new Emp_java();
	        try
	        {
	            Connection con=EmpDao.getConnection();
	            PreparedStatement ps=con.prepareStatement("select * from emp1" );
	            ResultSet rs=ps.executeQuery();
	            
	            while(rs.next())
	            {
	                Emp_java e1 = new Emp_java();
	                e1.setId(rs.getInt(1));
	                e1.setName(rs.getString(2));
	                e1.setSalary(rs.getInt(3));
	                
	            }
	            con.close();
	        }
	        catch(Exception e1)
	        {
	            System.out.println(e1);
	        }
			return null;
	        
	    }
	  		
	public static List<emp>AllEmployees(int start, int total) {
		// TODO Auto-generated method stub
			
		List<emp> list = new ArrayList<emp>();
		try {
				
			Connection con=getConnection();
			PreparedStatement ps=con.prepareStatement("select * from emp1 limit "+(start-1)+","+total);
		
		ResultSet rs=ps.executeQuery();
			
			while(rs.next())
			{
				
				emp e=new emp();
				e.setId(rs.getInt(1));
				e.setName(rs.getString(2));
				e.setSalary(rs.getInt(3));
				
				list.add(e);
				
				
			}
			con.close();
		}catch (Exception e)
		{
			System.out.println(e);
			
		}
		
		
		return list;
	}
	
}
