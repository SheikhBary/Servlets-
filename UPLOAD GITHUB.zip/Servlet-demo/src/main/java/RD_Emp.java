

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/RD")
public class RD_Emp extends HttpServlet {
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String u = request.getParameter("username");
		String p = request.getParameter("pass");

		
		if (u.equals("Sheikh") && p.equals("root"))
			
		{
			RequestDispatcher rd = request.getRequestDispatcher("WelcomeEmp");
			rd.forward(request, response);
			
		}else 
		{
			
			out.println("Sorry your username and password is incorrect");
			RequestDispatcher rd = request.getRequestDispatcher("/Emp.html");
			rd.include(request, response);
			
		}
		
		

	}

}
