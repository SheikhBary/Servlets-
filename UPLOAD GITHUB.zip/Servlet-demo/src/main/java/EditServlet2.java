

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/EditServlet2")
public class EditServlet2 extends HttpServlet {
	protected void doPost(HttpServletRequest req, HttpServletResponse res) 
			throws IOException,ServletException
	{
		
		res.setContentType("text/html");
		PrintWriter out =res.getWriter(); 
		String sid=req.getParameter("id");
		int id=Integer.parseInt(sid);
		String salary=req.getParameter("salary");
		int S=Integer.parseInt(salary);
		String name =req.getParameter("name");
		
		
		Emp_java e =new Emp_java();
		e.setId(id);
		e.setName(name);
		e.setSalary(S);
		
		int status=EmpDao.update(e);
		
		if(status>0)
		{
			res.sendRedirect("ViewServlet");
			
		}else {
		out.println("Sorry! Unable to update record");
		}
		
		out.close();
	}

}
