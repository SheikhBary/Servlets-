

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/cookie_ex1")
public class cookie_ex1 extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException 
	{
		
		try {
		
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		
		
		String n = req.getParameter("userName");
		out.println("Welcome :" + n);
		
		out.println("<form action='cookie2' method='post'> ");
		out.println("<input type='submit' value = 'go'>");
		out.println("</form>");
		
		Cookie ck = new Cookie("uname" , n);
		res.addCookie(ck);
		}catch (Exception e)
		{
			
			System.out.println(e);
		}
		
	}
}
