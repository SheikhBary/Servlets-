

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/hidden1")
public class hidden_servlet extends HttpServlet {
	
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		try {
			
			res.setContentType("text/html");
			PrintWriter out = res.getWriter();
			
			String n =req.getParameter("username");
			out.println("Welcome :" +n);
			
			out.print("<form action='hidden2' method='post'>");
			out.print("<input  type='hidden' name='username' value='"+n+"'>");
			out.print("<input type='submit' value ='go'>");
			out.print("/form");
			
			
			
		}catch (Exception e)
		{
			System.out.println(e);
		}
		
		
	}

	
}
