import java.sql.Date;

public class Emp_java {
	
	private int id,salary;
	private String name;
	

	public int getId()
	{
		
		return this.id;
	}
	
	
	public void setId(int id)
	{
		this.id=id;
	}
	
	public int getSalary()
	{
		
		return this.salary;
	}
	
	public void setSalary(int salary)
	{
		this.salary=salary;
	}
	
	
	//
	

	public String getName()
	{
		
		return this.name;
	}
	
	
	public void setName(String name)
	{
		this.name=name;
	}
	
	
	//
	

	//
	

	
	
	
	
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
	}

}
