

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.annotation.*;


@WebFilter(urlPatterns = { "/Servlet1" },
initParams=@WebInitParam(name="construction",value="yes"))
public class myFilterr implements Filter{
	
	 FilterConfig config;



	public void init(FilterConfig config) throws ServletException {
		
		this.config=config;
	}
	
	public void doFilter(ServletRequest req,ServletResponse res,FilterChain chain) throws IOException,ServletException { 
		PrintWriter out =res.getWriter(); 
		res.setContentType("text/html");
		String s = config.getInitParameter("config");
		if(s.equals("yes"))
			
		{
			out.print("This page is under construction");
		}else 
		{
				chain.doFilter(req, res);
		}
		
		
		
		} 
	
	
	
	public void destroy()
	
	{ }

}



