

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Servlet111
 */
@WebServlet("/Servlet111")
public class Servlet111 extends HttpServlet {
	
public void doGet (HttpServletRequest req, HttpServletResponse res) throws IOException
	
	{
		
		try {
			
			
			res.setContentType("text/html");
			PrintWriter out = res.getWriter();
			
			
			String n = req.getParameter("userName");
			out.println("Hello" +n);
			
			HttpSession session =req.getSession();
			session.setAttribute("uname", n);
			
			out.print("<a href ='servlet222'>visit</a>");
			out.close();
			
			
		}catch (Exception e)
		{
			
			System.out.println(e);
		}
		
	}
}
