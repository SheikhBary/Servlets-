
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/SaveServlet")
public class SaveServlet extends HttpServlet {
	public void doPost(HttpServletRequest req,HttpServletResponse res)
    {
        
        try
        {
            
            res.setContentType("text/html");
            PrintWriter out=res.getWriter();
            
            int id=Integer.parseInt(req.getParameter("id"));
            String name=req.getParameter("name");
            int salary=Integer.parseInt(req.getParameter("salary"));
            
            Emp_java e1 = new Emp_java();
            e1.setId(id);
            e1.setName(name);
            e1.setSalary(salary);
            int status = EmpDao.save(e1);
            
            if(status>0)
            {
                out.print("<p>Record saved successfully</p>");
                req.getRequestDispatcher("crud.html").include(req, res);
            }
            else {
                out.print("<p>Sorry Unable to Save record</p>");
            }
            out.close();
            
        }catch(Exception e) {
            System.out.println(e);
        
        }
        
        
    }
}
