

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class servlet222
 */
@WebServlet("/servlet222")
public class servlet222 extends HttpServlet {
	
	
public void doGet (HttpServletRequest req, HttpServletResponse res) throws IOException
	
	{
		
		try {
			
			
			res.setContentType("text/html");
			PrintWriter out = res.getWriter();
			
	
			
			HttpSession session =req.getSession();
			String n = (String) session.getAttribute("uname");
			out.println("Hello" +n);
			
			out.close();
			
			
		}catch (Exception e)
		{
			
			System.out.println(e);
		}
		
	}
}
