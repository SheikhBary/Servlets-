package sqlconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class empdao {
	public static Connection getConnection(){
		Connection con = null;
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/employee", "root","root");
		}catch (Exception e)
		
		{
			
			System.out.println(e);
		}
		return con;
		
		
	}
	
	public static int save(emp e1)
	
	{
		
		int status=0;
		try {
			
			Connection con =empdao.getConnection();
			PreparedStatement ps = con.prepareStatement("insert into emp1 values(?,?,?)");
			
			ps.setInt(1, e1.getId());
			ps.setString(2, e1.getName());
			ps.setInt(3, e1.getSalary());
			
			
			status=ps.executeUpdate();
			con.close();
		}catch (Exception e11)
		
		{
			System.out.println(e11);
		}
		return status;
	}
	
	public static int update (emp e)
	{
		int status=0;
try {
	
			Connection con =empdao.getConnection();
			PreparedStatement ps = con.prepareStatement("update emp1 set name=?salary=?where id=?");
			
			ps.setInt(1, e.getId());
			ps.setString(2, e.getName());
			ps.setInt(3, e.getSalary());
			
			 status = ps.executeUpdate();
			con.close();
		}catch (Exception e1)
		
		{
			System.out.println(e1);
		}
return status;
		
	}
	
	
	public static int delete(int id)  
	{
		int status=0;
try {
	
			Connection con =empdao.getConnection();
			PreparedStatement ps = con.prepareStatement("delete from emp_data where id=?");
			
			ps.setInt(1, id);

			
			 status = ps.executeUpdate();
			con.close();
		}catch (Exception e1)
		
		{
			System.out.println(e1);
		}

return status;
	}
	
	  public static emp getEmployeeById(int id)
	    {
	        emp e = new emp();
	        
	        try
	        {
	            Connection con=empdao.getConnection();
	            PreparedStatement ps=con.prepareStatement("select * from emp_d");
	            ResultSet rs=ps.executeQuery();
	            
	            if(rs.next())
	            {
	               
	                e.setId(rs.getInt(1));
	                e.setName(rs.getString(2));
	                e.setSalary(rs.getInt(3));
	                
	            }
	            con.close();
	        }
	        catch(Exception e1)
	        {
	            System.out.println(e1);
	        }
	        return e;
	    }
}
