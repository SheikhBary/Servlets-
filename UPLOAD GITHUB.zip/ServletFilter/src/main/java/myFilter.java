
import java.io.*;
import java.nio.file.DirectoryStream.Filter;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



@WebFilter(filterName = "myFilter", urlPatterns = { "/HelloServlet" })
public class myFilter implements Filter{
	
	public void init(FilterConfig arg0) throws ServletException {} 
	
	public void doFilter(ServletRequest req,ServletResponse res,FilterChain chain) throws IOException,ServletException { 
		
		PrintWriter out =res.getWriter(); 
		out.print("filter invoked before");
		chain.doFilter(req, res); 
		out.print("filter invoked after"); 
		
	
	}
	public void destroy() { }

	@Override
	public boolean accept(Object entry) throws IOException {
		// TODO Auto-generated method stub
		return false;
	}

}
