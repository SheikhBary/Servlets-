package session_tracking;


import java.util.*;



import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class EmpDao {
	
	
	public static Connection getConnection(){
		Connection con = null;
		
		try {
			
			Class.forName("com.mysql.jdbc.driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/employee", "root","root");
		}catch (Exception e)
		
		{
			
			System.out.println(e);
		}
		return con;
		
		
	}
	
	public static int save(Emp e)
	
	{
		
		int status=0;
		try {
			
			Connection con =EmpDao.getConnection();
			PreparedStatement ps = con.prepareStatement("insert into emp_data values(id,name,salary)");
			
			ps.setInt(1, e.getId());
			ps.setInt(2, e.getSalary());
			ps.setString(3, e.getName());
			
			status=ps.executeUpdate();
			con.close();
		}catch (Exception e1)
		
		{
			System.out.println(e1);
		}
		return status;
	}
	
	public static int update (Emp e)
	{
try {
	int status=0;
			Connection con =EmpDao.getConnection();
			PreparedStatement ps = con.prepareStatement("update emp set name=?salary=?where id=?");
			
			ps.setInt(1, e.setId());
			ps.setInt(2, e.setSalary());
			ps.setString(3, e.setName());
			
			 status = ps.executeUpdate();
			con.close();
		}catch (Exception e1)
		
		{
			System.out.println(e1);
		}
		
	}
	
	
	public static delete (int id)  
	{
try {
	int status=0;
			Connection con =EmpDao.getConnection();
			PreparedStatement ps = con.prepareStatement("delete from emp_data where id=?");
			
			ps.setInt(1, id);

			
			 status = ps.executeUpdate();
			con.close();
		}catch (Exception e1)
		
		{
			System.out.println(e1);
		}
		
	}
	
	
	
	
}
