package session_tracking;

public class Emp_java {
	
	private int id,salary;
	private String name, dept,date;

	public int getId()
	{
		
		return this.id;
	}
	
	
	public void setId(int id)
	{
		this.id=id;
	}
	
	public int getSalary()
	{
		
		return this.salary;
	}
	
	public void setSalary(int Salary)
	{
		this.salary=Salary;
	}
	
	
	//
	

	public String getName()
	{
		
		return this.name;
	}
	
	
	public void setName(String name)
	{
		this.name=name;
	}
	
	
	//
	
	public String getdept()
	{
		
		return this.dept;
	}
	
	
	public void setdept(String dept)
	{
		this.dept=dept;
	}
	
	//
	
	public String getdate()
	{
		
		return this.date;
	}
	
	
	public void setDate(String date)
	{
		this.date=date;
	}
	
	
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
	}

}
